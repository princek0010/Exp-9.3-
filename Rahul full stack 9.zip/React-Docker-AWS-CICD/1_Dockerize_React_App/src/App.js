import React from 'react';

export default function App(){
  return (
    <div style={{fontFamily:'Arial, sans-serif', textAlign:'center', marginTop:80}}>
      <h1>Hello from React (Dockerized)!</h1>
      <p>This is a minimal example for multi-stage Docker build.</p>
    </div>
  );
}
